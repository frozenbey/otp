#Twilio Details

account_sid = 'AC766b08a5a85081c9f9d1aa5b2b334980'
auth_token = 'f635ab39c20b080fc2301e508c14a981'
twilionumber = '+18447792376'
twiliosmsnumber = '+18447792376'

#FC Bot
API_TOKEN ='5822476697:AAGAckVcjDnpw-bbB_tYLFRfWsYv__Tuiyo'
#'5656962352:AAEXteRcvRZvFS4CMQNXQKdnscOxt_cdrKg'
#Host URL
callurl ='https://e29e-2601-3cb-700-1010-1fac-5200-8a0-b84b.ngrok.io'
#'https://e448-2601-3cb-700-1010-1fac-5200-8a0-b84b.ngrok.io '
twiliosmsurl ='https://e29e-2601-3cb-700-1010-1fac-5200-8a0-b84b.ngrok.io'
#'https://e29e-2601-3cb-700-1010-1fac-5200-8a0-b84b.ngrok.io'








