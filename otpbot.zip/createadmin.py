import sqlite3
from dbase import *

def main():
    adminid = input("5455403598")
    check = check_admin(5455403598)
    if check == True:
      print("Admin Zaten Var")
    else:
        print("Admin Bulunmadı")
        try:
            create_admin(5455403598)
            create_user_lifetime(5455403598)
        except:
            print('Bir Hata Oluştu')
        else:
         print('Admin Başarıyla Eklendi')
         create_admin(5455403598)
    james = fetch_UserData_table()
    print(james)
if __name__ == '__main__':
    main()